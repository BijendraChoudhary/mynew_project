<h1 align="center">
    <img src="images/logo.png" alt="python logo" valign="middle" height="50px"> Python Crash Course
</h1>

<p align="center">
    This repository references the evaluations of the <a href="https://www.coursera.org/learn/python-crash-course/">python coursera course</a>
</p>

## Usage:

To execute or modify this material it is necessary to use the <a href="https://jupyter.org/">jupyter notebook</a>

<img src="images/image.png" alt="jupyter notebook" height="300px"/>
<img src="images/image2.png" alt="jupyter notebook" height="300px"/>

## License:

[MIT](https://choosealicense.com/licenses/mit/)